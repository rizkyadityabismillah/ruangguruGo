func sender(message chan string) {

  for i := 1; i <= 5; i++ {
    data := fmt.Sprintf("message number %d", i)
    // mengirm data melalui channel
    message <- data
    time.Sleep(500 * time.Millisecond) // Simulate some work
  }
  // tutup channel karena tidak ada data lagi yang kita harus sampaikan
  close(message)

}

func receiver(id int, messages chan string, done chan bool) {
  for msg := range messages {
    fmt.Printf("Receiver %d received: %s\n", id, msg)
  }
  fmt.Printf("Receiver %d done receiving\n", id)
  done <- true
}

// func main() {

//   messages := make(chan string)
//   done := make(chan bool)

//   go sender(messages)

//   for i := 1; i < 4; i++ {
//     go receiver(i, messages, done)
//   }

//   receiversDone := 0
//   for {
//     select {
//     case <-done:
//       receiversDone++
//       if receiversDone == 3 {
//         fmt.Println("All messages received. Exiting receivers.")
//         return
//       }
//     }
//   }

// }
